/*
Abstract superclass for rest of student hierarchy
*/

/*
Jacob
9/12/2016
CS101-03
*/

//Any imports replace this comment

/*
                 Class Student
Variable or Constant          Purpose
____________________          _________________________________________
birthDate                     Date to store birth date
status                        String to store academic status
*/

public abstract class Student extends Person
{

  protected Date birthDate;
  protected String status;
  
}//People class end